# {{SERIE}} — Bíblia da série

> Modelo do kit **Desenho Animado**. Preencha as seções marcadas com (…). A seção "Episódios" é atualizada sozinha
> quando um episódio é aprovado. A skill `desenho-animado` lê este arquivo antes de cada ideia, roteiro e vídeo.

## Universo
{{DESCRICAO}}
- Do que a série fala: (… ex.: histórias reais e absurdas da história do mundo; leis estranhas; invenções por acidente)
- Promessa ao público: em 20 a 60 segundos, uma história surpreendente com uma virada irônica no final.
- Verdade ou lenda: o que é contado como fato é conferido; lenda é dita como lenda ("diz a lenda…").

## Público
- Quem assiste: (… ex.: curiosos de 16 a 40 anos que gostam de história e de "fatos que ninguém conta")
- Onde: TikTok, Instagram Reels e YouTube Shorts, no celular.

## Visual (fixo da série)
- Personagens 2D "cabeça de feijão" (contorno ameixa, olhos grandes, expressões fortes) num mundo 3D colorido,
  com contorno de tinta preta, texturas pintadas à mão, desfoque de profundidade e câmera sempre se movendo.
- Formato 9:16, 1080×1920, 30 fps. A duração é exatamente a da narração.
- Luz conta a história: dia para o normal, dourada para drama, azul-noite para explicação; flash branco em salto de tempo.
- Sem legenda por padrão (a pessoa pode pedir). Texto dentro da cena (placas, letreiros) pode, e precisa ler certo.

## Narração
- Voz: (… `pm_alex` narrador · `pm_santa` grave · `pf_dora` feminina · ou a voz gravada pela pessoa)
- Ritmo: ~3 palavras por segundo, frases de 8 a 15 palavras, números por extenso.
- Fórmula: gancho absurdo dito como fato → cenário em 1–2 frases → escalada em 2–4 batidas → "Mas quando…" (a virada,
  com comparação do dia a dia) → desfecho curto e irônico, que são as últimas palavras do vídeo.

## Som
- Trilha leve sintetizada a 50 % do volume da voz (−6 dB); para na frase da virada e entra um grave.
- Efeitos nos eventos (whoosh, batida, porta, moedas, risada, "ting" em revelações), sempre a 50 % ou menos da voz.
- Volume final −14 LUFS.

## Temas e épocas preferidos
(… ex.: antiguidade, idade média, 1800, ciência, animais, invenções, desastres, leis estranhas, acidentes de sorte;
2 a 3 histórias do Brasil a cada 10 ideias)

## Pode / não pode
- Pode: histórias reais documentadas, contos populares e folclore (avisando que é lenda), humor de exagero.
- Não pode: pessoas reais vivas como personagens ou alvo de piada, marcas e logotipos, nada gráfico, nada político,
  copiar o vídeo de outro criador plano a plano.

## Formato e frequência
- Duração: (… padrão 20 a 30 s; 45 a 60 s demora mais para renderizar) · Frequência: (…) · Plataformas: TikTok, Instagram e YouTube

## Episódios

"""Quadros + mix -> MP4 final, depois a conferência (faz o mesmo que kit/tools/finish.sh, sem bash).
uso (na pasta do projeto):  <python do kit> finalizar.py "Título do vídeo"
Normaliza o áudio a -14 LUFS com limitador, codifica H.264 + AAC, procura trechos congelados/pretos e gera out/qa_sheet.jpg."""
import re, subprocess, sys

titulo = sys.argv[1] if len(sys.argv) > 1 else "desenho"
saida = "out/" + re.sub(r"\s+", "-", titulo.strip()) + ".mp4"

def ff(*args, **kw):
    return subprocess.run(["ffmpeg", "-hide_banner", "-nostdin", *args], capture_output=True, text=True, **kw)

r = ff("-v", "error", "-y", "-i", "mix_raw.wav", "-af", "loudnorm=I=-14:TP=-1.5:LRA=7", "-ar", "48000", "-ac", "2", "mix.wav")
if r.returncode: sys.exit("mix.wav: " + r.stderr[-400:])
r = ff("-v", "error", "-y", "-framerate", "30", "-i", "frames/f%04d.jpg", "-i", "mix.wav", "-map", "0:v:0", "-map", "1:a:0",
       "-c:v", "libx264", "-preset", "slow", "-crf", "17", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
       "-shortest", "-movflags", "+faststart", saida)
if r.returncode: sys.exit("vídeo: " + r.stderr[-400:])
print(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-show_entries", "stream=width,height,r_frame_rate",
                      "-of", "compact", saida], capture_output=True, text=True).stdout.strip())
qa = ff("-i", saida, "-vf", "freezedetect=n=0.0005:d=0.4,blackdetect=d=0.05", "-an", "-f", "null", "-").stderr
problemas = [l.strip() for l in qa.splitlines() if "freeze_start" in l or "black_start" in l]
print("--- conferência:", "nenhum trecho congelado ou preto" if not problemas else "\n".join(problemas))
lufs = [l.strip() for l in ff("-i", saida, "-af", "ebur128", "-f", "null", "-").stderr.splitlines() if re.match(r"^\s+I:", l)]
if lufs: print("volume final:", lufs[-1])
ff("-v", "error", "-y", "-i", saida, "-vf", "fps=2,scale=180:-1,tile=10x4", "-frames:v", "1", "out/qa_sheet.jpg")
print(saida)

"""Cria o projeto de um episódio (faz o mesmo que kit/tools/setup.sh, sem precisar de bash, no Mac e no Windows).
uso (na pasta desenho-animado/):  <python do kit> novo_projeto.py projetos/ep01
Copia o motor e as ferramentas do kit/ (que fica somente leitura) para o projeto e monta web/toon.js.
Se o projeto já existe, só completa o que faltar: nunca apaga o trabalho feito (main.js, story.js, frames...)."""
import os, shutil, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
KIT = os.path.join(AQUI, "kit")
if len(sys.argv) < 2:
    sys.exit("informe a pasta do projeto, ex.: projetos/ep01")
P = os.path.abspath(sys.argv[1])
for d in ("web/lib", "work", "stills", "out", "frames"):
    os.makedirs(os.path.join(P, d), exist_ok=True)

def copiar(origem, destino):
    if not os.path.exists(destino):
        shutil.copy2(origem, destino)

for nome in os.listdir(os.path.join(KIT, "engine")):
    if nome.endswith((".js", ".html")):
        copiar(os.path.join(KIT, "engine", nome), os.path.join(P, "web", nome))
copiar(os.path.join(KIT, "vendor", "three.module.js"), os.path.join(P, "web", "lib", "three.module.js"))
for nome in os.listdir(os.path.join(KIT, "tools")):
    if nome.endswith((".py", ".mjs")):
        copiar(os.path.join(KIT, "tools", nome), os.path.join(P, nome))
copiar(os.path.join(KIT, "vendor", "vozes_ptbr.npz"), os.path.join(P, "vozes_ptbr.npz"))
copiar(os.path.join(AQUI, "finalizar.py"), os.path.join(P, "finalizar.py"))

# web/toon.js = toonbase.js + roman.js (refaça sempre que editar roman.js: python juntar_toon.py)
with open(os.path.join(P, "web", "toon.js"), "w", encoding="utf-8") as saida:
    for parte in ("toonbase.js", "roman.js"):
        with open(os.path.join(P, "web", parte), encoding="utf-8") as f:
            saida.write(f.read())
            saida.write("\n")
with open(os.path.join(P, "juntar_toon.py"), "w", encoding="utf-8") as f:
    f.write("import os\nw = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'web')\n"
            "open(os.path.join(w, 'toon.js'), 'w', encoding='utf-8').write(''.join(open(os.path.join(w, p), encoding='utf-8').read() + '\\n' for p in ('toonbase.js', 'roman.js')))\n"
            "print('web/toon.js atualizado')\n")
print("pronto:", P)
print("depois de editar web/roman.js rode: python juntar_toon.py (na pasta do projeto)")

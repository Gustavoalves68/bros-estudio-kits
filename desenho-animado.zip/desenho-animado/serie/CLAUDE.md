# {{SERIE}}

Série de **desenho animado** vertical: personagens 2D "cabeça de feijão" num mundo 3D colorido com contorno de tinta,
narração em português e trilha e efeitos sintetizados. Tudo é feito pelo motor em `desenho-animado/`.
Este arquivo só aponta o caminho: as regras estão na skill.

## Como produzir
- Siga a skill `.claude/skills/desenho-animado/SKILL.md` (ideias → roteiro → voz → planos → render → MP4).
- Leia a `biblia.md` antes de cada ideia ou roteiro.
- Python do kit: `desenho-animado/.venv/bin/python` no Mac ou `desenho-animado/.venv/Scripts/python.exe` no Windows.
  `node` e `ffmpeg` já estão no PATH; o navegador do render chega pela variável `PLAYWRIGHT_BROWSERS_PATH`.
- Cada episódio: `desenho-animado/projetos/<ep>/`, criado com `novo_projeto.py`. `desenho-animado/kit/` é somente leitura.

## Dois caminhos (use o que a regra "Recursos com IA" de cada pedido indicar)
### Caminho com gerador (ElevenLabs/Magnific ligados)
- Narração gerada por conector: UMA geração com o roteiro inteiro, só depois de mostrar o custo e a pessoa autorizar.
### Caminho sem gerador (nenhum recurso pago)
- Narração com a voz grátis embutida (`voz.py`) ou a voz gravada pela pessoa em `EP NN/brutos/`.
- Música e efeitos sintetizados pelo próprio motor (`audio.py` + `mix.py`).

## Entrega no Estúdio
- Vídeo final em `EP NN/final/vN.mp4`, capa em `EP NN/capa.png`; roteiro, narração e legenda do post em `EP NN/`.
- Render longo: em blocos de 100 quadros com `RESUME=1`, avisando o progresso entre os blocos.

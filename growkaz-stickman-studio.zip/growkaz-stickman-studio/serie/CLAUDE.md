# {{SERIE}}

Série feita com o **GrowKaz Stickman Studio original** — bonecos stickman cinematográficos (rim light, cenários 2.5D,
close-ups de rosto gigante, freeze-frames, overlays de dados, diagramas blueprint e planos 3D low-poly).
O estúdio e as skills estão aqui exatamente como vêm na skill `make-2d-video`, sem mudanças.
Este arquivo só aponta para eles — as regras estão nas skills.

## Como produzir
- Siga as skills em `.claude/skills/`: `make-2d-video` (pipeline completo), `new-video`, `video-styles`, `render-video`, `video-sound`.
- O estúdio já está instalado em `growkaz-stickman-studio/` (Etapa 2 da skill: pule a cópia e só rode o `tools/doctor.py`).
- Python: use `growkaz-stickman-studio/.venv/bin/python` no Mac ou `growkaz-stickman-studio/.venv/Scripts/python.exe` no Windows
  (numpy, scipy e faster-whisper já instalados pelo Estúdio). No Windows, rode os comandos pelo Git Bash, com `/` nos caminhos.
- `PLAYWRIGHT_BROWSERS_PATH` (Chromium do render) e `HF_HOME` (modelo Whisper "small") já chegam definidos pelo Estúdio,
  apontando para `dependencias/` — não é preciso instalar nem exportar nada.
- Cada vídeo: `growkaz-stickman-studio/projects/<slug>/` (ex.: `projects/ep01/`).

## Dois caminhos (use o que a regra "Recursos com IA" de cada pedido indicar)
### Caminho com gerador (Magnific/ElevenLabs ligados)
- Narração: gere UMA vez, com o roteiro inteiro, só depois de mostrar o custo estimado e a pessoa autorizar.
- Trilha/efeitos e imagens de referência podem vir do gerador, também com custo mostrado e autorização.
- Depois, siga a skill normalmente (tempos com Whisper, cenas, render, mix).
### Caminho sem gerador (nenhum recurso pago)
- Narração: peça a voz gravada pela pessoa (arquivo em `EP NN/brutos/`) e tire os tempos com o Whisper local.
- Música e efeitos: os sintetizados do próprio estúdio (`audio/music.py`, `audio/sfx.py`), como a skill já faz.
- Visual: só o motor de render dos stickmen (nenhuma imagem gerada).

## Entrega no Estúdio
- O vídeo final vai para a pasta do episódio (`EP NN/final/vN.mp4`) e a capa para `EP NN/capa.png`;
  os textos do episódio (roteiro, narração, legenda do post) também ficam em `EP NN/`.
- Recursos pagos (voz por IA, imagens geradas etc.) só com aprovação da pessoa — o Estúdio pede.
